import os
import random
import re
import discord
from discord import app_commands

# Track used replies so we never repeat
discord.utils.setup_logging()

used_default_replies = []
MAX_USED_MEMORY = 10
warnings = {}
active_channels = ["bot-chat", "emperor-ship"]

link_pattern = re.compile(r'https?:\/\/[^\s]+|www\.[^\s]+|discord\.gg\/[^\s]*|t\.me\/[^\s]+|bit\.ly\/[^\s]+|short\.link\/[^\s]+', re.IGNORECASE)

bad_words = ["fuck", "fck", "fuk", "fucking", "fucker", "motherfucker", "wtf", "shit", "bitch", "bastard", "cunt", "dick", "pussy", "asshole", "ass", "nigga", "nigger", "retard", "whore", "slut", "idiot", "stupid", "moron", "stfu", "kys", "kill yourself"]

# ======================= KNOWLEDGE BASE =======================
# Massive pre-written smart answers for common questions
# This makes the bot appear intelligent without needing an API key!

KNOWLEDGE_BASE = {
    # Science & Nature
    "sunlight": "Sunlight is the light and energy that comes from the Sun! ☀️ It takes about 8 minutes to reach Earth and travels at 300,000 km per second. Without it, life on Earth wouldn't exist!",
    "sun": "The Sun is a giant ball of hot plasma at the center of our solar system! 🌞 It's about 4.6 billion years old and makes up 99.86% of the mass in our entire solar system. Wild, right?",
    "sky blue": "The sky looks blue because of something called Rayleigh scattering! 💙 Sunlight hits air molecules and blue light scatters more than other colors because it travels in shorter, smaller waves.",
    "rainbow": "Rainbows happen when sunlight passes through water droplets in the air! 🌈 The light bends (refraction), reflects inside the drop, then bends again — splitting white light into 7 colors: ROYGBIV!",
    "earth": "Earth is the 3rd planet from the Sun and the only known planet with life! 🌍 It's about 4.54 billion years old, 71% covered in water, and spinning at about 1,670 km/h at the equator!",
    "moon": "The Moon is Earth's only natural satellite! 🌙 It's about 384,400 km away, has no atmosphere, and was likely formed 4.5 billion years ago when a Mars-sized object collided with Earth!",
    "stars": "Stars are massive balls of glowing gas, mostly hydrogen and helium! ⭐ They shine because of nuclear fusion in their core — turning hydrogen into helium and releasing insane amounts of energy!",
    "gravity": "Gravity is the force that pulls objects toward each other! 🍎 Earth pulls us down, which is why we don't float away. The more mass something has, the stronger its gravity. Even YOU have gravity!",
    "black hole": "A black hole is a region where gravity is so strong that nothing — not even light — can escape! 🕳️ They form when massive stars collapse. The nearest known one is about 1,600 light-years away!",
    "galaxy": "A galaxy is a huge collection of gas, dust, and billions of stars held together by gravity! 🌌 Our Milky Way has about 100-400 billion stars and is about 100,000 light-years across!",
    "universe": "The universe is everything — all of space, time, matter, and energy! 🌠 It's about 13.8 billion years old and still expanding. There might be 2 TRILLION galaxies out there!",
    "aurora": "The aurora (Northern/Southern Lights) happens when charged particles from the Sun hit Earth's atmosphere! 🌌 The particles excite oxygen and nitrogen, making them glow in green, pink, and purple!",
    "thunder": "Thunder is the sound of lightning! ⚡ When lightning strikes, it heats the air to 30,000°C (5x hotter than the Sun's surface!) — the air expands explosively, creating the boom we hear!",
    "tornado": "A tornado is a violently rotating column of air connecting a cloud to the ground! 🌪️ The strongest ones have winds over 480 km/h. The US gets about 1,200 per year — more than anywhere else!",
    "volcano": "A volcano is a rupture in Earth's crust that lets magma, ash, and gas escape! 🌋 The tallest active volcano is Mauna Loa in Hawaii. The biggest eruption ever was Mount Tambora in 1815!",
    "earthquake": "Earthquakes happen when tectonic plates suddenly move past each other! 🌍 The energy released creates seismic waves. The largest ever recorded was the 1960 Chile earthquake — magnitude 9.5!",
    "tsunami": "A tsunami is a series of massive ocean waves usually caused by underwater earthquakes! 🌊 They can travel at 800 km/h in deep water and reach heights of 30+ meters when they hit shore!",
    "cloud": "Clouds are made of tiny water droplets or ice crystals that form when warm air rises and cools! ☁️ There are 10 main types. A single cumulus cloud can weigh about 500,000 kg (1.1 million pounds)!",
    "lightning": "Lightning is a giant electrical discharge in the atmosphere! ⚡ It happens when positive and negative charges separate in clouds. A bolt can be 5x hotter than the Sun's surface and carry 1 billion volts!",
    "ocean": "Oceans cover 71% of Earth's surface and hold 97% of all water! 🌊 The deepest point is the Mariana Trench at about 11,000 meters — deeper than Mount Everest is tall! Only 5% has been explored!",
    "rain": "Rain is water droplets that fall from clouds when they get too heavy! 🌧️ A single raindrop falls at about 9-10 m/s. The most rain ever recorded in 24 hours was 1.825 meters on Réunion Island in 1952!",
    "snow": "Snow forms when water vapor in clouds freezes into ice crystals! ❄️ Each snowflake has a unique shape based on temperature and humidity. The largest snowflake ever recorded was 38 cm across!",
    "wind": "Wind is moving air caused by differences in air pressure! 💨 When air heats up it rises, creating low pressure. Cooler air rushes in to fill the gap — that's wind! The fastest wind on Earth was 407 km/h!",
    "hurricane": "A hurricane is a massive tropical storm with winds over 119 km/h! 🌀 They form over warm ocean water and can be 1,000 km wide. The strongest ever recorded was Hurricane Patricia in 2015 (345 km/h winds)!",
    "fossil": "Fossils are preserved remains of ancient animals and plants! 🦴 They form when organisms get buried quickly and minerals replace their body parts over millions of years. The oldest fossils are 3.5 billion years old!",
    "dinosaur": "Dinosaurs were reptiles that ruled Earth for 165 million years! 🦕 They went extinct 66 million years ago, likely due to an asteroid impact. Birds are actually modern dinosaurs — they survived!",
    "evolution": "Evolution is how species change over generations through natural selection! 🧬 Organisms with traits that help them survive pass those traits to offspring. It's why giraffes have long necks and why bacteria become drug-resistant!",
    "dna": "DNA (deoxyribonucleic acid) is the molecule that carries genetic instructions for life! 🧬 It's shaped like a double helix and made of 4 building blocks: A, T, C, and G. If stretched out, your DNA would reach the Sun and back 60 times!",
    "atom": "An atom is the smallest unit of matter! ⚛️ It's made of protons (positive), neutrons (neutral), and electrons (negative) orbiting the nucleus. Everything you see — including you — is made of atoms!",
    "electricity": "Electricity is the flow of electric charge, usually electrons through a conductor! ⚡ It powers everything. A single lightning bolt carries enough energy to power a house for a month!",
    "magnet": "Magnets create invisible magnetic fields that attract iron and repel other magnets! 🧲 Earth itself is a giant magnet with north and south poles. Some animals like pigeons and turtles use Earth's magnetic field to navigate!",
    "solar system": "Our solar system has 8 planets orbiting the Sun! 🪐 It formed 4.6 billion years ago from a giant cloud of gas and dust. Jupiter is so big that 1,300 Earths could fit inside it!",
    "planet": "A planet is a large object that orbits a star, is round from its own gravity, and has cleared its orbit! 🪐 We have 8 in our solar system. The hottest is Venus at 462°C. The coldest is Neptune at -214°C!",
    "mars": "Mars is the 4th planet from the Sun, known as the Red Planet! 🔴 It gets its color from iron oxide (rust). It's about half Earth's size. Scientists are planning to send humans there by the 2030s!",
    "jupiter": "Jupiter is the largest planet in our solar system! 🪐 It's a gas giant with a Great Red Spot storm that's been raging for at least 400 years. It has 95 known moons, including Ganymede — the biggest moon in the solar system!",
    "saturn": "Saturn is the 6th planet, famous for its beautiful rings! 💫 The rings are made of ice and rock chunks, some as big as houses. It's less dense than water — if you had a big enough bathtub, Saturn would float!",
    "neptune": "Neptune is the 8th and farthest planet from the Sun! 🌊 It's an ice giant with winds up to 2,100 km/h — the fastest in the solar system. It takes 165 Earth years to orbit the Sun once!",
    "pluto": "Pluto was considered the 9th planet until 2006, when it was reclassified as a dwarf planet! ❄️ It's smaller than Earth's moon and has a heart-shaped ice plain called Tombaugh Regio. A day on Pluto lasts 153 Earth hours!",
    "comet": "A comet is a ball of ice, dust, and rock that orbits the Sun! ☄️ When near the Sun, they develop glowing tails that can stretch millions of kilometers. Halley's Comet returns every 76 years — next visit: 2061!",
    "asteroid": "An asteroid is a rocky object orbiting the Sun, smaller than a planet! 🪨 Most are in the asteroid belt between Mars and Jupiter. The biggest, Ceres, is about 940 km wide. The asteroid that killed dinosaurs was about 10 km wide!",
    "meteor": "A meteor is a streak of light caused by a space rock burning up in Earth's atmosphere! 🌠 If it hits the ground, it's called a meteorite. About 25 million meteors enter Earth's atmosphere every day!",
    "eclipse": "An eclipse happens when one celestial body blocks another! 🌑 A solar eclipse is when the Moon blocks the Sun. A lunar eclipse is when Earth blocks sunlight from reaching the Moon. Solar eclipses happen about 2-5 times per year!",
    "tide": "Tides are the rise and fall of sea levels caused by the Moon's gravity! 🌊 The Moon pulls water toward it, creating a high tide. There are usually 2 high and 2 low tides each day. The highest tides can be 16 meters!",
    "season": "Seasons happen because Earth's axis is tilted 23.5°! 🌸☀️🍂❄️ When your hemisphere tilts toward the Sun, it's summer (more direct sunlight). When it tilts away, it's winter. The equator has no seasons — it's warm all year!",
    "climate": "Climate is the long-term weather pattern of a region! 🌍 It's different from weather (short-term). Earth's climate is warming due to greenhouse gases — mainly CO2 from burning fossil fuels. The last 8 years were the hottest on record!",
    "global warming": "Global warming is the long-term heating of Earth's climate system! 🌡️ Since the late 1800s, Earth's average temperature has risen about 1.1°C. It's mainly caused by burning fossil fuels which release CO2. We need to act fast!",
    "greenhouse effect": "The greenhouse effect is when gases like CO2 trap heat in Earth's atmosphere! 🏠 It's like a blanket — some warmth is good (without it Earth would be -18°C!), but too much CO2 from human activity is overheating the planet!",
    "photosynthesis": "Photosynthesis is how plants make food using sunlight! 🌱 They take CO2 from air, water from roots, and use sunlight to make glucose (sugar) and oxygen. It's why forests are called the 'lungs of the Earth'!",
    "respiration": "Respiration is how living things convert food into energy! 🫁 We breathe in oxygen, which breaks down glucose in our cells, producing energy + CO2 + water. You do it about 20,000 times per day without thinking!",
    "digestion": "Digestion is how your body breaks down food into nutrients! 🍎 It starts in your mouth (saliva), continues in the stomach (acid), and finishes in the small intestine. The whole trip takes 6-8 hours on average!",
    "heart": "Your heart is a muscle that pumps blood through your body! ❤️ It beats about 100,000 times per day, pumping 7,500 liters of blood. That's enough to fill 40 bathtubs! It has its own electrical system — it can beat even outside the body!",
    "brain": "Your brain is the control center of your body! 🧠 It has about 86 billion neurons and uses 20% of your energy despite being only 2% of your body weight. It processes information at about 268 mph (432 km/h)!",
    "eye": "Your eye is one of the most complex organs! 👁️ It has over 2 million working parts and can distinguish about 10 million colors. The cornea is the only tissue with no blood supply — it gets oxygen directly from air!",
    "blood": "Blood is the liquid that transports oxygen, nutrients, and waste in your body! 🩸 An adult has about 5 liters. Red blood cells live 120 days. Your body makes 2 million new ones every second!",
    "bone": "Bones are hard tissues that support and protect your body! 🦴 Adults have 206 bones. Babies are born with about 270 — some fuse together as they grow. The smallest bone is in your ear (3mm). The largest is your femur!",
    "muscle": "Muscles are tissues that contract to move your body! 💪 You have over 600 of them. The strongest is the masseter (jaw) — it can close with 900 Newtons of force. The busiest? Your heart muscle, never stopping!",
    "skin": "Skin is your body's largest organ! 🧴 An adult has about 2 square meters of it. It renews itself completely every 27 days. You're basically wearing a new skin every month without realizing it!",
    "virus": "A virus is a tiny infectious agent that needs a host cell to reproduce! 🦠 They're not alive by themselves. The smallest are 20 nanometers wide. COVID-19 is caused by a coronavirus. Antibiotics don't work on viruses!",
    "bacteria": "Bacteria are single-celled microorganisms found everywhere! 🦠 Most are harmless or helpful (like gut bacteria that help digestion). But some cause diseases. There are about 5 nonillion (5×10³⁰) bacteria on Earth!",
    "cell": "A cell is the basic unit of life! 🔬 You have about 37 TRILLION cells. The largest human cell is the egg (0.1mm). The smallest is the sperm head. Cells have organelles like mitochondria — the 'powerhouses' that make energy!",
    "mitochondria": "Mitochondria are the 'powerhouses' of your cells! ⚡ They convert food into ATP (energy). They have their own DNA and might have once been separate bacteria that merged with cells billions of years ago!",
    "antibiotic": "Antibiotics are medicines that kill bacteria! 💊 They were first discovered by Alexander Fleming in 1928 (penicillin). But overuse causes antibiotic resistance — bacteria evolve to survive them. Use wisely!",
    "vaccine": "A vaccine trains your immune system to fight diseases! 💉 It contains weakened or dead pathogens (or parts of them). Your body learns to recognize and attack them. Vaccines have saved millions of lives — smallpox was eradicated by vaccines!",
    "immune system": "Your immune system defends against germs and diseases! 🛡️ It has white blood cells, antibodies, and organs like the spleen and lymph nodes. It remembers past infections — that's why vaccines and some diseases only happen once!",
    "sleep": "Sleep is a state of rest where your body and brain recover! 😴 Adults need 7-9 hours. During deep sleep, your brain clears toxins, forms memories, and your body repairs cells. Missing sleep hurts focus, mood, and health!",
    "dream": "Dreams are images and stories your brain creates while sleeping! 🌙 Most happen during REM sleep. Scientists think they help process emotions and memories. You have 3-7 dreams per night but usually forget them within minutes of waking!",
    "water": "Water is a transparent, tasteless liquid essential for all known life! 💧 It covers 71% of Earth. Your body is about 60% water. Water is the only substance that naturally exists as solid (ice), liquid, and gas (steam) on Earth!",
    "fire": "Fire is the rapid chemical reaction of combustion! 🔥 It needs fuel, oxygen, and heat. Fire produces light and heat. The hottest flames (like from a welding torch) can reach 3,000°C!",
    "ice": "Ice is frozen water! ❄️ It expands when freezing (unlike most substances), which is why pipes burst in winter and ice floats. If ice sank, lakes would freeze from the bottom up and kill all aquatic life!",
    "sound": "Sound is a vibration that travels through air, water, or solids as waves! 🔊 It can't travel in space (no medium). The speed of sound in air is about 343 m/s. The loudest sound ever recorded was the Krakatoa eruption in 1883, heard 5,000 km away!",
    "light": "Light is electromagnetic radiation that lets us see! 💡 It travels at 299,792 km/s — the fastest speed in the universe. Light takes 8 minutes from the Sun, 4 years from the nearest star (Proxima Centauri), and 13.8 billion years from the edge of the observable universe!",
    "laser": "A laser is a device that produces intense, focused light! 🔴 The word stands for 'Light Amplification by Stimulated Emission of Radiation.' Lasers are used in everything from eye surgery to barcode scanners to cutting steel!",
    "robot": "A robot is a machine that can be programmed to perform tasks! 🤖 The word comes from the Czech word 'robota' meaning forced labor. The first industrial robot was Unimate in 1961. Now we have robots that can walk, talk, and even do backflips!",
    "internet": "The internet is a global network of connected computers! 🌐 It started as ARPANET in 1969 with just 4 computers. Now over 5.3 billion people use it. Data travels as packets that find the best route — like digital mail!",
    "wifi": "Wi-Fi is wireless networking technology that uses radio waves! 📶 The name doesn't mean anything officially. It uses 2.4 GHz or 5 GHz frequencies. Your Wi-Fi router sends data at nearly the speed of light — just through air instead of wires!",
    "computer": "A computer is an electronic machine that processes data! 💻 The first electronic computer (ENIAC) filled a room and weighed 27 tons in 1945. Now your phone is millions of times more powerful. It follows instructions called programs at billions of operations per second!",
    "ai": "AI (Artificial Intelligence) is when computers can learn, reason, and make decisions! 🤖 It uses algorithms and data to recognize patterns. ChatGPT, Siri, and recommendation systems all use AI. It's not 'thinking' like humans — it's pattern matching at massive scale!",
    "machine learning": "Machine learning is a type of AI where computers learn from data! 📊 Instead of being programmed with rules, they find patterns themselves. You use ML daily — spam filters, Netflix recommendations, facial recognition, and autocorrect all use it!",
    "programming": "Programming is writing instructions (code) that computers can execute! 💻 There are hundreds of languages: Python (easy), JavaScript (websites), C++ (games), Java (apps), and more. Code is just text that gets translated into 1s and 0s computers understand!",
    "code": "Code is instructions written in a programming language! 💻 Computers only understand binary (1s and 0s). Code gets translated (compiled or interpreted) into binary. A single app might contain millions of lines of code!",
    "binary": "Binary is a number system using only 0 and 1! 0️⃣1️⃣ Computers use it because transistors have two states: on (1) and off (0). Every photo, video, and song on your device is ultimately stored as long strings of 1s and 0s!",
    "hacker": "A hacker is someone skilled at understanding and manipulating computer systems! 👨‍💻 The term isn't inherently bad — 'white hat' hackers help find security flaws. 'Black hat' hackers use skills maliciously. The term originally meant creative, clever programmers in the 1960s!",
    "cybersecurity": "Cybersecurity is protecting computers and networks from attacks! 🛡️ Hackers use techniques like phishing (fake emails), malware (viruses), and DDoS (flooding servers). Good security uses strong passwords, 2FA, and encryption!",
    "encryption": "Encryption scrambles data so only authorized people can read it! 🔐 It's like a secret code. Modern encryption uses complex math. Your WhatsApp messages are end-to-end encrypted — even WhatsApp can't read them!",
    "blockchain": "Blockchain is a digital record that's spread across many computers! ⛓️ Each 'block' contains data and links to the previous block. It's nearly impossible to hack because changing one block would require changing all following blocks across the whole network!",
    "bitcoin": "Bitcoin is a digital currency created in 2009 by Satoshi Nakamoto! ₿ It's decentralized — no government or bank controls it. Transactions are recorded on a blockchain. Only 21 million Bitcoins will ever exist, making it scarce!",
    "nft": "An NFT (Non-Fungible Token) is a unique digital certificate of ownership stored on a blockchain! 🖼️ Unlike Bitcoin, each NFT is one-of-a-kind. People use them for digital art, music, and collectibles. Critics say it's overhyped — supporters say it empowers artists!",
    "metaverse": "The metaverse is a virtual shared space combining physical and digital reality! 🥽 It's like a 3D internet you can walk through. Companies like Meta and Epic Games are building it. You use avatars to interact, play games, and even buy virtual real estate!",
    "vr": "VR (Virtual Reality) immerses you in a computer-generated world! 🥽 You wear a headset that tracks your head movements and displays 3D images. The first VR headset was created in the 1960s, but modern ones like the Quest 2 make it affordable and popular!",
    "ar": "AR (Augmented Reality) overlays digital content onto the real world! 📱 Pokemon GO made it famous. Your phone camera shows the real world while adding virtual elements. Apple's Vision Pro and Snapchat filters use AR!",
    "quantum computing": "Quantum computing uses quantum mechanics to process information! ⚛️ Unlike regular computers (bits = 0 or 1), quantum computers use qubits that can be 0, 1, or both simultaneously. This makes them potentially millions of times faster for certain problems!",
    "nuclear energy": "Nuclear energy comes from splitting atoms (fission) or joining them (fusion)! ⚛️ It produces massive energy with no CO2. One uranium pellet (size of a pencil eraser) produces as much energy as 1 ton of coal! Fusion powers the Sun and could be Earth's future energy!",
    "solar energy": "Solar energy comes from converting sunlight into electricity! ☀️ Solar panels use silicon cells that release electrons when hit by light. The cost dropped 90% since 2010! In some places, solar is now the cheapest electricity in history!",
    "wind energy": "Wind energy converts air movement into electricity using turbines! 💨 Modern turbines can be 150+ meters tall with blades longer than a Boeing 747 wing. A single large turbine can power 1,400 homes!",
    "electric car": "Electric cars run on batteries instead of gas! 🔋 They convert 85-90% of electrical energy into motion (gas cars only convert 20-30%). Tesla popularized them, but now every major automaker makes EVs. Range anxiety is fading — some go 600+ km on a charge!",
    "space x": "SpaceX is Elon Musk's aerospace company founded in 2002! 🚀 They revolutionized space by making reusable rockets. The Falcon 9 can land itself vertically! They've launched thousands of Starlink satellites and are building Starship for Mars missions!",
    "nasa": "NASA (National Aeronautics and Space Administration) is the US space agency! 🚀 Founded in 1958, they put humans on the Moon in 1969, built the Space Shuttle, and now operate the ISS. They're working on the Artemis program to return humans to the Moon by 2026!",
    "iss": "The ISS (International Space Station) orbits Earth at 400 km altitude! 🛰️ It's been continuously occupied since 2000. It's about the size of a football field and travels at 28,000 km/h — meaning it orbits Earth 16 times per day!",
    "mars mission": "Humans want to colonize Mars in the coming decades! 🔴 Elon Musk aims for 1 million people by 2050. Challenges include radiation, low gravity, and creating a self-sustaining habitat. NASA's Perseverance rover is already collecting samples for future return missions!",

    # Roblox & Gaming
    "blox fruits": "Blox Fruits is a popular Roblox game inspired by One Piece! 🍓🗡️ You can be a pirate or marine, eat fruits that give superpowers, fight bosses, and explore islands. There are 3 seas and dozens of fruits with unique abilities!",
    "roblox": "Roblox is a platform where users can play and create games! 🎮 It was launched in 2006 and now has over 70 million daily active users. Players use Robux (premium currency) to buy items. Popular games include Blox Fruits, Adopt Me, and Doors!",
    "minecraft": "Minecraft is a sandbox game where you build and explore! ⛏️ Created by Markus 'Notch' Persson in 2011, it's the best-selling game ever (300+ million copies). You mine blocks, craft tools, fight mobs, and can build literally anything your imagination allows!",
    "fortnite": "Fortnite is a battle royale game by Epic Games! 🎮 100 players drop on an island and fight to be last standing. It became a cultural phenomenon in 2017. The building mechanic is unique — you collect materials and build structures mid-fight!",
    "valorant": "Valorant is a tactical shooter by Riot Games! 🎯 It combines CS:GO-style gunplay with hero abilities. 5v5 matches where one team plants a bomb (Spike) and the other defends. Each 'Agent' has unique skills. It's huge in esports!",
    "gta": "GTA (Grand Theft Auto) is an action-adventure series by Rockstar Games! 🚗 The most recent, GTA V, came out in 2013 and has sold 190+ million copies. It's known for open-world chaos, heists, and satirical humor. GTA VI is coming in 2025!",
    "pubg": "PUBG (PlayerUnknown's Battlegrounds) started the battle royale craze! 🍗 100 players parachute onto a map, loot weapons, and fight to survive. The 'winner winner chicken dinner' phrase is iconic. It inspired Fortnite, Apex Legends, and many others!",
    "call of duty": "Call of Duty is a massively popular first-person shooter franchise! 🔫 Started in 2003, it's known for fast multiplayer and cinematic campaigns. Warzone (the free battle royale) has over 100 million players. New games release annually!",
    "apex legends": "Apex Legends is a free battle royale by Respawn/EA! 🏆 60 players in squads of 3, each character has unique abilities. It introduced the ping system (communicating without voice chat) which revolutionized accessibility. Over 100 million players!",
    "league of legends": "League of Legends (LoL) is the biggest MOBA game by Riot Games! ⚔️ 5v5 matches where you control a 'champion' with unique abilities. It's free to play but makes billions from cosmetics. Worlds tournament fills stadiums with 100,000+ live viewers!",
    "esports": "Esports is competitive video gaming at a professional level! 🏆 Top players earn millions in prize money. Games like LoL, Dota 2, CS:GO, and Valorant have pro leagues. The biggest tournament is Dota 2's The International with $40+ million prize pools!",

    # History & Geography
    "pyramid": "The Egyptian Pyramids were built as tombs for pharaohs over 4,500 years ago! 🔺 The Great Pyramid of Giza was the tallest man-made structure for 3,800 years. It has 2.3 million stone blocks averaging 2.5 tons each. Built without modern machinery!",
    "taj mahal": "The Taj Mahal is a white marble mausoleum in India, built by Emperor Shah Jahan in 1632! 🕌 It took 20,000 workers 22 years to complete. It's perfectly symmetrical except for the tomb of the emperor, added later. It's considered one of the New Seven Wonders!",
    "eiffel tower": "The Eiffel Tower was built in 1889 for the World's Fair in Paris! 🗼 It was supposed to be temporary but became iconic. It's 330 meters tall and shrinks 6 inches in winter due to metal contraction. 7 million people visit it every year!",
    "great wall": "The Great Wall of China is a series of fortifications built over centuries! 🏯 It's about 21,196 km long. Construction started in the 7th century BC. It's not one continuous wall — it's many walls built by different dynasties and connected!",
    "colosseum": "The Colosseum in Rome is the largest ancient amphitheater ever built! 🏛️ Completed in 80 AD, it could hold 50,000-80,000 spectators. Gladiators fought here, and naval battles were staged by flooding the arena floor!",
    "world war": "World War II (1939-1945) was the deadliest conflict in human history! 💣 About 70-85 million people died. It ended with the atomic bombings of Hiroshima and Nagasaki. WWII reshaped global politics, leading to the Cold War and the United Nations!",
    "cold war": "The Cold War was a period of tension between the US and USSR from 1947-1991! 🌍 It was 'cold' because no direct fighting happened between superpowers, but proxy wars occurred in Korea, Vietnam, and Afghanistan. It ended with the Soviet Union's collapse!",
    "moon landing": "Humans first landed on the Moon on July 20, 1969! 🌙 Neil Armstrong and Buzz Aldrin were the first. Armstrong's famous words: 'That's one small step for man, one giant leap for mankind.' 12 people have walked on the Moon — all Americans!",
    "berlin wall": "The Berlin Wall divided East and West Berlin from 1961-1989! 🧱 It was 155 km long and symbolized the Cold War. When it fell on November 9, 1989, people celebrated by chipping away pieces with hammers. Germany reunified a year later!",
    "india": "India is the 7th largest country and the most populous democracy in the world! 🇮🇳 It has 1.4+ billion people and 22 official languages. It's the birthplace of 4 major religions: Hinduism, Buddhism, Jainism, and Sikhism. The Taj Mahal and Bollywood are world-famous!",
    "pakistan": "Pakistan is a South Asian country with 240+ million people! 🇵🇰 It was created in 1947 when British India split. It has the world's 5th largest military, and K2 (the world's 2nd highest mountain) is on its border. Urdu and English are official languages!",
    "china": "China is the world's most populous country with 1.4+ billion people! 🇨🇳 It's one of the oldest continuous civilizations (4,000+ years). It has the 2nd largest economy and invented paper, gunpowder, the compass, and printing! The Great Wall is visible from space (myth, but still impressive)!",
    "usa": "The USA is the 3rd largest country with 50 states and 330+ million people! 🇺🇸 Founded in 1776, it has the world's largest economy and most powerful military. It's known for Hollywood, Silicon Valley, NASA, and diverse culture from every corner of the globe!",
    "russia": "Russia is the world's largest country — it spans 11 time zones! 🇷🇺 It covers 1/8 of Earth's land area. It sent the first human to space (Yuri Gagarin, 1961). Moscow's Red Square and St. Basil's Cathedral are iconic landmarks!",
    "japan": "Japan is an island nation known for technology, anime, and culture! 🇯🇵 It has 125 million people. Tokyo is the world's largest metropolitan area (37+ million). Japan created anime, manga, Nintendo, PlayStation, and bullet trains that go 320 km/h!",
    "korea": "South Korea is a tech powerhouse with 51 million people! 🇰🇷 It invented K-pop, K-dramas, and Samsung. Seoul has the fastest internet in the world. Korean culture went global with BTS, Squid Game, and Korean BBQ! North Korea is a completely different story.",
    "africa": "Africa is the 2nd largest continent with 54 countries and 1.4 billion people! 🌍 It's where human life originated about 200,000 years ago. It has the Sahara Desert, the Nile River, and incredible wildlife. It's also the youngest continent — the median age is just 19!",
    "antarctica": "Antarctica is the coldest, driest, and windiest continent! ❄️ It's covered in ice averaging 1.9 km thick. It holds 70% of Earth's fresh water. No country owns it — the Antarctic Treaty keeps it peaceful for science. Temperatures reach -89.2°C!",
    "amazon": "The Amazon Rainforest is the world's largest tropical rainforest! 🌳 It covers 5.5 million km² across 9 countries. It produces 20% of Earth's oxygen and has 10% of all known species. Deforestation is a major threat — we've lost 17% of it in 50 years!",
    "sahara": "The Sahara is the world's largest hot desert! 🏜️ It's about the size of the USA (9 million km²). Despite being mostly sand, it has snow-capped mountains! It was once green with lakes and rivers about 5,000-11,000 years ago!",
    "mount everest": "Mount Everest is the world's highest mountain at 8,848.86 meters! 🏔️ It's in Nepal/Tibet border. First summited in 1953 by Edmund Hillary and Tenzing Norgay. Over 6,000 people have climbed it, but about 300 have died trying. Bodies remain on the mountain as landmarks!",
    "mariana trench": "The Mariana Trench is the deepest part of the ocean at about 11,000 meters! 🌊 Only 27 people have been to the bottom — fewer than have been to the Moon! The pressure is 1,000x sea level. James Cameron visited in 2012 in a solo submersible!",

    # Animals
    "elephant": "Elephants are the largest land animals! 🐘 African elephants can weigh 6,350 kg. They have 40,000 muscles in their trunk alone! They mourn their dead, have excellent memories, and can communicate through vibrations in the ground!",
    "lion": "Lions are called the 'King of the Jungle' though they live in grasslands! 🦁 Only male lions have manes. A lion's roar can be heard 8 km away. Lions sleep 20 hours a day. Prides are led by females who do most of the hunting!",
    "tiger": "Tigers are the largest cats and excellent swimmers! 🐅 Unlike most cats, they LOVE water. Their stripes are like fingerprints — no two tigers have the same pattern. Sadly, fewer than 5,000 remain in the wild due to habitat loss and poaching!",
    "cheetah": "Cheetahs are the fastest land animals, reaching 120 km/h in 3 seconds! 🐆 That's faster than most sports cars! But they can only maintain top speed for about 20-30 seconds. Their black 'tear marks' help reduce sun glare while hunting!",
    "penguin": "Penguins are flightless birds that live in the Southern Hemisphere! 🐧 The Emperor Penguin is the largest (1.2m tall). They can dive 500+ meters deep and hold their breath 20 minutes. They slide on their bellies — it's called 'tobogganing'!",
    "dolphin": "Dolphins are highly intelligent marine mammals! 🐬 They use echolocation (sound waves) to navigate and hunt. They have names — each has a unique whistle! Dolphins sleep with one half of their brain at a time so they can keep breathing!",
    "whale": "Blue whales are the largest animals to EVER exist — bigger than dinosaurs! 🐋 They can reach 30 meters and weigh 180 tons. Their tongue alone weighs as much as an elephant! Their heart is the size of a small car. They eat 4 tons of krill per day!",
    "shark": "Sharks have been around for 450 million years — before trees existed! 🦈 They have multiple rows of teeth and can lose up to 35,000 in a lifetime. Most are harmless to humans. You're more likely to be killed by a vending machine than a shark!",
    "octopus": "Octopuses are incredibly intelligent invertebrates! 🐙 They have 3 hearts, blue blood, and 9 brains (one in each arm + main brain). They can solve puzzles, escape tanks, and change color instantly. They're masters of camouflage!",
    "eagle": "Eagles are powerful birds of prey with incredible eyesight! 🦅 They can spot a rabbit from 3 km away. Their vision is 4-8x sharper than humans. The Harpy Eagle has talons as big as a grizzly bear's claws!",
    "owl": "Owls are nocturnal hunters with amazing adaptations! 🦉 Their eyes are tube-shaped and fixed in place (they turn their head up to 270° instead). They can hear a mouse heartbeat under snow from 30 meters. Their feathers make them completely silent flyers!",
    "bee": "Bees are vital pollinators responsible for 1/3 of our food! 🐝 A single hive can have 50,000-80,000 bees. They communicate through a 'waggle dance' that tells others where flowers are. Bees can recognize human faces and count up to 4!",
    "ant": "Ants are incredibly strong for their size — they can carry 10-50x their body weight! 🐜 There are about 20 quadrillion ants on Earth (2.5 million per human). They farm fungus, keep 'livestock' (aphids), and some species can glide through the air!",
    "spider": "Spiders aren't insects — they're arachnids (8 legs, no antennae)! 🕷️ They produce silk stronger than steel by weight. Some spiders can fly using 'ballooning' — they release silk threads and let wind carry them!",
    "butterfly": "Butterflies taste with their feet! 🦋 They have 4 wings but only use 2 for flying. Monarch butterflies migrate 4,800 km from Canada to Mexico — a journey that takes multiple generations! They navigate using the Sun and Earth's magnetic field!",
    "crocodile": "Crocodiles are living dinosaurs — they've existed for 240 million years! 🐊 They have the strongest bite of any animal (16,000+ Newtons). They can live 70-100 years and survive without food for a YEAR! They cry while eating, but it's not from emotion — it's to lubricate their eyes!",
    "snake": "Snakes are legless reptiles that evolved from lizards! 🐍 Some can 'fly' by flattening their bodies and gliding between trees (paradise flying snake). The smallest is 10 cm. The longest is the reticulated python at 10+ meters. Only about 600 of 3,900 species are venomous!",
    "dog": "Dogs were the first animals domesticated by humans, about 15,000-40,000 years ago! 🐕 They have 300 million smell receptors (we have 6 million). They can understand up to 250 words and gestures. Their nose prints are unique like human fingerprints!",
    "cat": "Cats have been companions to humans for about 9,500 years! 🐱 They spend 70% of their lives sleeping. They can jump 6x their body length. They have 32 muscles in each ear (we have 6). A group of cats is called a 'clowder'!",
    "giraffe": "Giraffes are the tallest land animals at up to 5.5 meters! 🦒 Their necks have the same number of vertebrae as humans (7) — just much bigger! Their tongues are 45 cm long and black to prevent sunburn. A baby giraffe falls 1.8 meters at birth!",

    # Math & Numbers
    "pi": "Pi (π) is the ratio of a circle's circumference to its diameter! 🥧 It's about 3.14159... but the digits go on forever without repeating. It's been calculated to over 100 TRILLION digits! Pi Day is March 14 (3/14).",
    "infinity": "Infinity is a concept representing something without end! ♾️ In math, some infinities are bigger than others. The set of all real numbers is a 'larger infinity' than all whole numbers. Mind-blowing, right?",
    "prime number": "A prime number is only divisible by 1 and itself! 🔢 2, 3, 5, 7, 11, 13... There are infinitely many primes, but no formula generates all of them. The largest known prime (as of 2024) has over 24 million digits!",
    "fibonacci": "The Fibonacci sequence is 0, 1, 1, 2, 3, 5, 8, 13... each number is the sum of the two before it! 🌀 It appears everywhere in nature: flower petals, pinecones, galaxy spirals, and even your DNA structure!",
    "golden ratio": "The Golden Ratio (φ) is about 1.618 and appears in art, nature, and architecture! 🏛️ It's considered the most aesthetically pleasing proportion. The Parthenon, Mona Lisa, and even your credit card use it. It also appears in sunflowers and nautilus shells!",
    "zero": "Zero is one of the most important inventions in math history! 0️⃣ It was invented in India around 500 AD. Before that, people just left blank spaces! Zero made modern math, computing, and science possible. Your phone literally couldn't exist without it!",

    # Fun Facts
    "honey": "Honey never spoils! 🍯 Archaeologists found 3,000-year-old honey in Egyptian tombs that was still edible. Bees visit 2 million flowers and fly 55,000 km to make 500g of honey. Honey is basically bee vomit — they regurgitate nectar multiple times!",
    "banana": "Bananas are technically berries, but strawberries aren't! 🍌 They're slightly radioactive because of potassium-40. A 'banana equivalent dose' is used to measure tiny radiation exposure. Slipping on banana peels was a real hazard in the early 1900s — that's why it's a cartoon trope!",
    "chocolate": "Chocolate comes from cacao seeds that were used as currency by the Aztecs! 🍫 It contains compounds that trigger the same brain reactions as being in love. The smell alone increases theta brain waves, which cause relaxation. Switzerland eats the most per person (8.8 kg/year)!",
    "coffee": "Coffee is the 2nd most traded commodity in the world after oil! ☕ It was discovered when Ethiopian goats ate coffee berries and got hyper. Finland drinks the most per person (12 kg/year). Coffee beans aren't beans — they're seeds from a fruit!",
    "ice cream": "Ice cream was invented in China around 200 BC using milk and rice packed in snow! 🍨 The tallest ice cream cone ever made was 3.08 meters. Americans eat the most per person (23 kg/year). It takes 4 liters of milk to make 3.8 liters of ice cream!",
    "pizza": "Pizza was invented in Naples, Italy around the 1700s! 🍕 The most expensive pizza ever cost $12,000 and took 72 hours to make. Hawaii has a spam pizza that's actually popular. The world's largest pizza was 1,261 square meters — bigger than a basketball court!",
    "time": "Time is the ongoing sequence of events! ⏰ The concept of dividing an hour into 60 minutes comes from the ancient Sumerians who used a base-60 number system. GPS satellites have to account for Einstein's theory of relativity — time moves slightly slower on Earth than in space!",
    "money": "Money is a medium of exchange! 💵 The first coins were made in Lydia (Turkey) around 600 BC. Paper money was invented in China. The largest banknote ever was the 100 trillion dollar bill from Zimbabwe — but it was worth only about $0.40 USD!",
    "language": "There are about 7,000 languages spoken today! 🗣️ Papua New Guinea alone has 840 languages — the most of any country. Languages are dying at a rate of about 2 per month. English has the most words (over 170,000 in the Oxford dictionary)!",
    "music": "Music is organized sound that evokes emotion! 🎵 The oldest known musical instrument is a 40,000-year-old bone flute from Germany. Music affects your brain's dopamine system — that's why your favorite song gives you chills!",
    "color": "Color is how our eyes and brain interpret different wavelengths of light! 🌈 Red has the longest wavelength (~700nm), violet the shortest (~400nm). Some animals see colors we can't — mantis shrimp have 16 color receptors (we have 3)!",
    "rainbow color": "There are 7 main colors in a rainbow: Red, Orange, Yellow, Green, Blue, Indigo, and Violet! 🌈 ROYGBIV! Isaac Newton chose 7 colors because he thought it matched the musical scale. Some scientists argue indigo isn't distinct enough and say there are really 6!",

    # Time & Age
    "new year": "New Year is celebrated when a calendar year ends and a new one begins! 🎉 The most common date is January 1 (Gregorian calendar). But different cultures celebrate at different times — Chinese New Year (lunar calendar), Rosh Hashanah (Jewish), and Nowruz (Persian)!",
    "birthday": "Birthdays mark the anniversary of someone's birth! 🎂 The tradition of birthday cakes started with the ancient Greeks who made round cakes for Artemis (moon goddess). The song 'Happy Birthday' is the most recognized song in English!",
    "year": "A year is the time Earth takes to orbit the Sun — about 365.25 days! 🌍 That's why we have leap years every 4 years (except century years not divisible by 400). A light-year is the distance light travels in one year: 9.46 TRILLION kilometers!",
    "day": "A day is the time Earth takes to rotate once on its axis — about 24 hours! 🌅 But Earth's rotation is slowing due to the Moon's gravity (about 1.4 milliseconds per century). Dinosaurs experienced 23-hour days!",
    "hour": "An hour is 60 minutes or 3,600 seconds! ⏰ The ancient Egyptians divided day and night into 12 parts each, creating the 24-hour system. Before clocks, people used sundials during the day and water clocks at night!",
    "minute": "A minute is 60 seconds! ⏱️ The word comes from Latin 'pars minuta prima' meaning 'first small part.' The smallest measurable time interval is the Planck time: 5.39×10⁻⁴⁴ seconds. Time gets weird at that scale!",
    "second": "A second is defined by atomic clocks using cesium atoms! ⏱️ One second = 9,192,631,770 vibrations of a cesium-133 atom. Atomic clocks are so accurate they'd only lose 1 second in 300 million years!",
    "century": "A century is 100 years! 📅 We just entered the 21st century (2001-2100). The 20th century saw more technological change than all previous centuries combined: cars, planes, space travel, internet, smartphones, and nuclear power!",
    "millennium": "A millennium is 1,000 years! 🏛️ We crossed into the 3rd millennium in 2001 (not 2000 — there's no year 0!). The last millennium saw the rise and fall of empires, the Renaissance, the Industrial Revolution, and the Information Age!",

    # Religion & Culture
    "islam": "Islam is a monotheistic religion founded by Prophet Muhammad (PBUH) in 610 AD in Mecca! ☪️ Muslims believe in one God (Allah) and follow the Quran. There are 1.9 billion Muslims worldwide. The Five Pillars are: faith, prayer, charity, fasting, and pilgrimage!",
    "christianity": "Christianity is the world's largest religion with 2.4 billion followers! ✝️ It's based on the teachings of Jesus Christ. The Bible is its holy book. Christians believe Jesus is the Son of God and that he rose from the dead after crucifixion!",
    "hinduism": "Hinduism is the world's oldest living religion, dating back over 4,000 years! 🕉️ It has no single founder and is more a way of life than a rigid set of rules. Key concepts include karma, dharma, and reincarnation. There are 330 million+ deities!",
    "buddhism": "Buddhism was founded by Siddhartha Gautama (the Buddha) around 500 BC in India! ☸️ The goal is to reach Nirvana — liberation from suffering. There are about 500 million Buddhists. The core teachings are the Four Noble Truths and the Eightfold Path!",
    "ramadan": "Ramadan is the 9th month of the Islamic lunar calendar when Muslims fast from dawn to sunset! 🌙 It's a time of spiritual reflection, prayer, and charity. The fast is broken daily with Iftar. Eid al-Fitr marks the end with celebrations and feasting!",
    "eid": "Eid al-Fitr is the celebration marking the end of Ramadan! 🎉 Muslims wear new clothes, give to charity (Zakat al-Fitr), visit family, and enjoy special foods. Eid al-Adha commemorates Prophet Ibrahim's willingness to sacrifice his son and involves sacrificing an animal!",
    "christmas": "Christmas celebrates the birth of Jesus Christ on December 25! 🎄 Though the exact date is unknown. Traditions include gift-giving (inspired by the 3 Wise Men), Christmas trees (German tradition), and Santa Claus (inspired by St. Nicholas, a 4th-century bishop)!",
    "diwali": "Diwali is the Hindu 'Festival of Lights' celebrating the victory of light over darkness! 🪔 It lasts 5 days. People light oil lamps (diyas), set off fireworks, exchange sweets, and clean their homes. It commemorates Lord Rama's return after 14 years in exile!",
    "holi": "Holi is the Hindu 'Festival of Colors' celebrating spring and love! 🌈 People throw colored powders and water at each other. It commemorates the burning of the demoness Holika. It's a time to forgive, repair relationships, and celebrate new beginnings!",

    # General Knowledge
    "apple": "Apple Inc. is one of the world's most valuable companies, founded by Steve Jobs in 1976! 🍎 The first Apple computer was built in a garage. Apple made the iPhone (2007), which revolutionized smartphones. They're now worth over $3 TRILLION!",
    "google": "Google started as a search engine in 1998 by Larry Page and Sergey Brin at Stanford! 🔍 The name comes from 'googol' (10^100). It processes over 8.5 billion searches per day. They own Android, YouTube, Chrome, and are now called Alphabet Inc!",
    "youtube": "YouTube is the world's largest video platform, created in 2005! 📺 Over 2.7 billion people use it monthly. 500+ hours of video are uploaded every MINUTE. The most-viewed video is 'Baby Shark' with 14+ billion views. It was bought by Google for $1.65 billion in 2006!",
    "tiktok": "TikTok is a short-form video app that took the world by storm! 📱 It was launched in 2016 by ByteDance (China). It has over 1 billion active users. The algorithm is scarily good at knowing what you like. It's the most downloaded app of all time!",
    "facebook": "Facebook was created by Mark Zuckerberg in 2004 at Harvard! 👤 It started as a college-only site. Now it has 3 billion+ users. They bought Instagram ($1B, 2012), WhatsApp ($19B, 2014), and Oculus ($2B, 2014). The parent company is now Meta!",
    "instagram": "Instagram is a photo/video sharing app launched in 2010! 📸 It was bought by Facebook for $1 billion when it had only 13 employees! It has 2+ billion users. Stories, Reels, and filters are its main features. The most-followed account is Cristiano Ronaldo (600M+)!",
    "twitter": "Twitter (now X) was founded in 2006 by Jack Dorsey! 🐦 The first tweet was 'just setting up my twttr.' It limited posts to 140 characters (now 280). Elon Musk bought it for $44 billion in 2022 and renamed it X!",
    "whatsapp": "WhatsApp is the world's most popular messaging app with 2+ billion users! 💬 Founded in 2009, it was bought by Facebook for $19 billion in 2014 — at the time, the biggest tech acquisition ever! It's end-to-end encrypted, meaning even WhatsApp can't read your messages!",
    "netflix": "Netflix started as a DVD rental service in 1997! 📺 They pioneered streaming in 2007. Now they have 260+ million subscribers and produce their own shows (Stranger Things, Squid Game). They spend $17 billion per year on content!",
    "spotify": "Spotify is the world's largest music streaming service with 600+ million users! 🎵 Founded in Sweden in 2006. It has 100+ million songs. Artists earn about $0.003-$0.005 per stream. The most-streamed artist of all time is Drake!",
    "amazon": "Amazon started as an online bookstore in 1994 by Jeff Bezos! 📦 Now it's the world's largest online retailer selling everything. They also own AWS (cloud computing that powers 30% of the internet), Whole Foods, and Twitch. Bezos was briefly the world's richest person!",
    "tesla": "Tesla is an electric vehicle and clean energy company founded in 2003! 🚗 Elon Musk joined in 2004. They made EVs mainstream with the Model S, 3, X, Y. Tesla cars can drive semi-autonomously. They're also building the world's largest battery factory!",
    "microsoft": "Microsoft was founded by Bill Gates and Paul Allen in 1975! 💻 They created Windows (used by 1.4 billion people), Office, Xbox, and now own LinkedIn, GitHub, and Minecraft! Their cloud service Azure is the 2nd largest after AWS!",
    "samsung": "Samsung is a South Korean tech giant founded in 1938! 📱 They started as a trading company. Now they're the world's largest smartphone maker (Galaxy series). They also make TVs, chips, and even build ships! Their revenue is 1/4 of South Korea's entire GDP!",
    "iphone": "The iPhone was unveiled by Steve Jobs in 2007 and changed the world! 📱 It combined an iPod, phone, and internet communicator. Apple has sold over 2.3 billion iPhones. The first iPhone didn't even have copy/paste or an App Store — those came later!",
    "android": "Android is the world's most popular mobile operating system, created by Google! 🤖 It powers 3+ billion devices (70% market share). It was originally developed for digital cameras, not phones! It's open-source, meaning anyone can modify it!",

    # Health & Body
    "water drink": "You should drink about 2-3 liters of water per day! 💧 Your body is 60% water. Water helps digestion, temperature regulation, and removing waste. Even mild dehydration (1-2% loss) affects mood and brain function. Thirst is actually a sign you're already dehydrated!",
    "sleep need": "Most adults need 7-9 hours of sleep! 😴 During sleep, your brain clears toxic proteins, forms memories, and repairs cells. Chronic sleep deprivation increases risk of heart disease, diabetes, and Alzheimer's. One night of 4 hours sleep = same impairment as being drunk!",
    "exercise": "Adults should get 150 minutes of moderate exercise per week! 🏃 That's just 21 minutes daily. Exercise reduces risk of heart disease, stroke, diabetes, and depression. It also boosts brain power — students who exercise regularly score 20% higher on tests!",
    "healthy food": "A healthy diet includes fruits, vegetables, whole grains, lean proteins, and healthy fats! 🥗 The Mediterranean diet is considered the healthiest. Processed foods high in sugar and trans fats increase inflammation. Your gut bacteria (microbiome) affect mood, immunity, and even weight!",
    "stress": "Stress is your body's response to challenges! 😰 Short-term stress can be helpful (focus, performance). Chronic stress damages your heart, brain, and immune system. Techniques: deep breathing, exercise, meditation, and talking to friends. Laughter literally reduces stress hormones!",
    "smoking": "Smoking is the leading preventable cause of death worldwide! 🚭 It kills 8 million people annually. One cigarette contains 7,000+ chemicals, 70 of which cause cancer. Within 20 minutes of quitting, heart rate drops. Within a year, heart disease risk is cut in half!",
    "alcohol": "Alcohol is a depressant that slows brain function! 🍺 Moderate drinking (1-2 drinks/day) may have slight heart benefits, but heavy drinking damages the liver, brain, and increases cancer risk. Alcohol poisoning happens at about 0.4% blood alcohol level — about 10+ drinks quickly!",
    "sugar": "Added sugar should be less than 10% of daily calories! 🍬 The average person eats 17 teaspoons daily (way too much!). Sugar spikes insulin, causes energy crashes, and contributes to diabetes, obesity, and heart disease. Read labels — sugar hides in bread, sauces, and 'healthy' cereals!",

    # Space & Future
    "alien": "Aliens (extraterrestrial life) are hypothetical life forms outside Earth! 👽 Given 2 trillion galaxies, scientists think life probably exists somewhere. The Drake Equation estimates 1,000-100,000,000 civilizations in our galaxy alone. SETI has been listening for radio signals since 1985!",
    "time travel": "Time travel is theoretically possible via Einstein's general relativity! ⏰ Wormholes, rotating black holes, or traveling near light speed could do it. But paradoxes (like the grandfather paradox) make it problematic. So far, no time travelers have visited us — or have they? 😏",
    "mars colony": "Elon Musk plans a Mars colony with 1 million people by 2050! 🔴 Challenges: radiation (no magnetic field), low gravity (38% of Earth's), and creating a self-sustaining habitat. NASA's Artemis program aims for the Moon first as a stepping stone to Mars!",
    "ai future": "AI is advancing rapidly! 🤖 GPT-4 can pass the bar exam and solve complex problems. Some experts predict human-level AI by 2030, others say 2050+. Concerns include job displacement, bias, and 'alignment' (making AI do what we actually want). The future is wild!",
    "robot future": "Robots are becoming more capable! 🤖 Boston Dynamics' Atlas can do backflips and parkour. Surgical robots perform precise operations. Delivery robots roam sidewalks. The question isn't if robots will change society — it's how fast and who benefits!",
    "climate future": "Earth's average temperature has risen 1.1°C since pre-industrial times! 🌡️ At 1.5°C, coral reefs die. At 2°C, coastal cities flood. We need to cut emissions in half by 2030 and reach net-zero by 2050. The technology exists — the political will is the challenge!",
    "space future": "The future of space is exciting! 🚀 NASA is returning to the Moon (Artemis). SpaceX is building Starship for Mars. Blue Origin builds space stations. Private space tourism is starting. The space economy could be $1 TRILLION by 2040!",
    "future": "The future is shaped by today's choices! 🔮 By 2050: AI may be smarter than humans, we might have Mars colonies, renewable energy could dominate, and life expectancy might hit 100. But climate change, inequality, and ethical AI use are challenges we must solve together!",
}

# Also check for partial matches
KNOWLEDGE_ALIASES = {
    "sun light": "sunlight", "sun shine": "sunlight", "sun energy": "sunlight",
    "why sky blue": "sky blue", "blue sky": "sky blue", "why is sky blue": "sky blue",
    "what is rainbow": "rainbow", "how rainbow form": "rainbow",
    "how old earth": "earth", "earth age": "earth", "earth old": "earth",
    "moon fact": "moon", "about moon": "moon",
    "star fact": "stars", "about star": "stars",
    "gravity fact": "gravity", "about gravity": "gravity",
    "blackhole": "black hole", "black hole fact": "black hole",
    "milky way": "galaxy", "about galaxy": "galaxy",
    "universe fact": "universe", "about universe": "universe",
    "northern lights": "aurora", "aurora borealis": "aurora",
    "thunder sound": "thunder", "why thunder": "thunder",
    "tornado fact": "tornado", "about tornado": "tornado",
    "volcano fact": "volcano", "about volcano": "volcano",
    "earthquake fact": "earthquake", "about earthquake": "earthquake",
    "tsunami fact": "tsunami", "about tsunami": "tsunami",
    "cloud fact": "cloud", "about cloud": "cloud",
    "lightning fact": "lightning", "about lightning": "lightning",
    "ocean fact": "ocean", "about ocean": "ocean", "sea fact": "ocean",
    "rain fact": "rain", "about rain": "rain",
    "snow fact": "snow", "about snow": "snow",
    "wind fact": "wind", "about wind": "wind",
    "hurricane fact": "hurricane", "about hurricane": "hurricane",
    "fossil fact": "fossil", "about fossil": "fossil",
    "dinosaur fact": "dinosaur", "about dinosaur": "dinosaur",
    "evolution fact": "evolution", "about evolution": "evolution",
    "dna fact": "dna", "about dna": "dna",
    "atom fact": "atom", "about atom": "atom",
    "electricity fact": "electricity", "about electricity": "electricity",
    "magnet fact": "magnet", "about magnet": "magnet",
    "solar system fact": "solar system", "about solar system": "solar system",
    "planet fact": "planet", "about planet": "planet",
    "mars fact": "mars", "about mars": "mars",
    "jupiter fact": "jupiter", "about jupiter": "jupiter",
    "saturn fact": "saturn", "about saturn": "saturn",
    "neptune fact": "neptune", "about neptune": "neptune",
    "pluto fact": "pluto", "about pluto": "pluto",
    "comet fact": "comet", "about comet": "comet",
    "asteroid fact": "asteroid", "about asteroid": "asteroid",
    "meteor fact": "meteor", "about meteor": "meteor", "shooting star": "meteor",
    "eclipse fact": "eclipse", "about eclipse": "eclipse",
    "tide fact": "tide", "about tide": "tide",
    "season fact": "season", "about season": "season",
    "climate change": "climate", "global warming fact": "global warming",
    "greenhouse effect fact": "greenhouse effect",
    "photosynthesis fact": "photosynthesis", "about photosynthesis": "photosynthesis",
    "respiration fact": "respiration", "about respiration": "respiration",
    "digestion fact": "digestion", "about digestion": "digestion",
    "heart fact": "heart", "about heart": "heart",
    "brain fact": "brain", "about brain": "brain",
    "eye fact": "eye", "about eye": "eye",
    "blood fact": "blood", "about blood": "blood",
    "bone fact": "bone", "about bone": "bone",
    "muscle fact": "muscle", "about muscle": "muscle",
    "skin fact": "skin", "about skin": "skin",
    "virus fact": "virus", "about virus": "virus",
    "bacteria fact": "bacteria", "about bacteria": "bacteria",
    "cell fact": "cell", "about cell": "cell",
    "mitochondria fact": "mitochondria", "about mitochondria": "mitochondria",
    "antibiotic fact": "antibiotic", "about antibiotic": "antibiotic",
    "vaccine fact": "vaccine", "about vaccine": "vaccine",
    "immune system fact": "immune system", "about immune system": "immune system",
    "sleep fact": "sleep", "about sleep": "sleep",
    "dream fact": "dream", "about dream": "dream",
    "water fact": "water", "about water": "water",
    "fire fact": "fire", "about fire": "fire",
    "ice fact": "ice", "about ice": "ice",
    "sound fact": "sound", "about sound": "sound",
    "light fact": "light", "about light": "light",
    "laser fact": "laser", "about laser": "laser",
    "robot fact": "robot", "about robot": "robot",
    "internet fact": "internet", "about internet": "internet",
    "wifi fact": "wifi", "about wifi": "wifi",
    "computer fact": "computer", "about computer": "computer",
    "ai fact": "ai", "about ai": "ai", "artificial intelligence": "ai",
    "machine learning fact": "machine learning", "about machine learning": "machine learning",
    "programming fact": "programming", "about programming": "programming",
    "code fact": "code", "about code": "code",
    "binary fact": "binary", "about binary": "binary",
    "hacker fact": "hacker", "about hacker": "hacker",
    "cybersecurity fact": "cybersecurity", "about cybersecurity": "cybersecurity",
    "encryption fact": "encryption", "about encryption": "encryption",
    "blockchain fact": "blockchain", "about blockchain": "blockchain",
    "bitcoin fact": "bitcoin", "about bitcoin": "bitcoin",
    "nft fact": "nft", "about nft": "nft",
    "metaverse fact": "metaverse", "about metaverse": "metaverse",
    "vr fact": "vr", "about vr": "vr", "virtual reality": "vr",
    "ar fact": "ar", "about ar": "ar", "augmented reality": "ar",
    "quantum computing fact": "quantum computing", "about quantum computing": "quantum computing",
    "nuclear energy fact": "nuclear energy", "about nuclear energy": "nuclear energy",
    "solar energy fact": "solar energy", "about solar energy": "solar energy",
    "wind energy fact": "wind energy", "about wind energy": "wind energy",
    "electric car fact": "electric car", "about electric car": "electric car",
    "spacex fact": "space x", "about spacex": "space x", "elon musk space": "space x",
    "nasa fact": "nasa", "about nasa": "nasa",
    "iss fact": "iss", "about iss": "iss", "space station": "iss",
    "mars mission fact": "mars mission", "about mars mission": "mars mission",
    "blox fruit": "blox fruits", "bloxfruit": "blox fruits", "bloxfruits": "blox fruits",
    "roblox fact": "roblox", "about roblox": "roblox",
    "minecraft fact": "minecraft", "about minecraft": "minecraft",
    "fortnite fact": "fortnite", "about fortnite": "fortnite",
    "valorant fact": "valorant", "about valorant": "valorant",
    "gta fact": "gta", "about gta": "gta",
    "pubg fact": "pubg", "about pubg": "pubg",
    "call of duty fact": "call of duty", "about call of duty": "call of duty",
    "apex legends fact": "apex legends", "about apex legends": "apex legends",
    "league of legends fact": "league of legends", "about league of legends": "league of legends",
    "esports fact": "esports", "about esports": "esports",
    "pyramid fact": "pyramid", "about pyramid": "pyramid",
    "taj mahal fact": "taj mahal", "about taj mahal": "taj mahal",
    "eiffel tower fact": "eiffel tower", "about eiffel tower": "eiffel tower",
    "great wall fact": "great wall", "about great wall": "great wall",
    "colosseum fact": "colosseum", "about colosseum": "colosseum",
    "world war fact": "world war", "about world war": "world war",
    "cold war fact": "cold war", "about cold war": "cold war",
    "moon landing fact": "moon landing", "about moon landing": "moon landing",
    "berlin wall fact": "berlin wall", "about berlin wall": "berlin wall",
    "india fact": "india", "about india": "india",
    "pakistan fact": "pakistan", "about pakistan": "pakistan",
    "china fact": "china", "about china": "china",
    "usa fact": "usa", "about usa": "usa", "america fact": "usa",
    "russia fact": "russia", "about russia": "russia",
    "japan fact": "japan", "about japan": "japan",
    "korea fact": "korea", "about korea": "korea",
    "africa fact": "africa", "about africa": "africa",
    "antarctica fact": "antarctica", "about antarctica": "antarctica",
    "amazon fact": "amazon", "about amazon": "amazon",
    "sahara fact": "sahara", "about sahara": "sahara",
    "mount everest fact": "mount everest", "about mount everest": "mount everest",
    "mariana trench fact": "mariana trench", "about mariana trench": "mariana trench",
    "elephant fact": "elephant", "about elephant": "elephant",
    "lion fact": "lion", "about lion": "lion",
    "tiger fact": "tiger", "about tiger": "tiger",
    "cheetah fact": "cheetah", "about cheetah": "cheetah",
    "penguin fact": "penguin", "about penguin": "penguin",
    "dolphin fact": "dolphin", "about dolphin": "dolphin",
    "whale fact": "whale", "about whale": "whale",
    "shark fact": "shark", "about shark": "shark",
    "octopus fact": "octopus", "about octopus": "octopus",
    "eagle fact": "eagle", "about eagle": "eagle",
    "owl fact": "owl", "about owl": "owl",
    "bee fact": "bee", "about bee": "bee",
    "ant fact": "ant", "about ant": "ant",
    "spider fact": "spider", "about spider": "spider",
    "butterfly fact": "butterfly", "about butterfly": "butterfly",
    "crocodile fact": "crocodile", "about crocodile": "crocodile",
    "snake fact": "snake", "about snake": "snake",
    "dog fact": "dog", "about dog": "dog",
    "cat fact": "cat", "about cat": "cat",
    "giraffe fact": "giraffe", "about giraffe": "giraffe",
    "pi fact": "pi", "about pi": "pi", "what is pi": "pi",
    "infinity fact": "infinity", "about infinity": "infinity",
    "prime number fact": "prime number", "about prime number": "prime number",
    "fibonacci fact": "fibonacci", "about fibonacci": "fibonacci",
    "golden ratio fact": "golden ratio", "about golden ratio": "golden ratio",
    "zero fact": "zero", "about zero": "zero",
    "honey fact": "honey", "about honey": "honey",
    "banana fact": "banana", "about banana": "banana",
    "chocolate fact": "chocolate", "about chocolate": "chocolate",
    "coffee fact": "coffee", "about coffee": "coffee",
    "ice cream fact": "ice cream", "about ice cream": "ice cream",
    "pizza fact": "pizza", "about pizza": "pizza",
    "time fact": "time", "about time": "time",
    "money fact": "money", "about money": "money",
    "language fact": "language", "about language": "language",
    "music fact": "music", "about music": "music",
    "color fact": "color", "about color": "color",
    "rainbow color fact": "rainbow color", "about rainbow color": "rainbow color",
    "new year fact": "new year", "about new year": "new year",
    "birthday fact": "birthday", "about birthday": "birthday",
    "year fact": "year", "about year": "year",
    "day fact": "day", "about day": "day",
    "hour fact": "hour", "about hour": "hour",
    "minute fact": "minute", "about minute": "minute",
    "second fact": "second", "about second": "second",
    "century fact": "century", "about century": "century",
    "millennium fact": "millennium", "about millennium": "millennium",
    "islam fact": "islam", "about islam": "islam",
    "christianity fact": "christianity", "about christianity": "christianity",
    "hinduism fact": "hinduism", "about hinduism": "hinduism",
    "buddhism fact": "buddhism", "about buddhism": "buddhism",
    "ramadan fact": "ramadan", "about ramadan": "ramadan",
    "eid fact": "eid", "about eid": "eid",
    "christmas fact": "christmas", "about christmas": "christmas",
    "diwali fact": "diwali", "about diwali": "diwali",
    "holi fact": "holi", "about holi": "holi",
    "apple fact": "apple", "about apple": "apple",
    "google fact": "google", "about google": "google",
    "youtube fact": "youtube", "about youtube": "youtube",
    "tiktok fact": "tiktok", "about tiktok": "tiktok",
    "facebook fact": "facebook", "about facebook": "facebook",
    "instagram fact": "instagram", "about instagram": "instagram",
    "twitter fact": "twitter", "about twitter": "twitter",
    "whatsapp fact": "whatsapp", "about whatsapp": "whatsapp",
    "netflix fact": "netflix", "about netflix": "netflix",
    "spotify fact": "spotify", "about spotify": "spotify",
    "amazon company fact": "amazon", "about amazon company": "amazon",
    "tesla fact": "tesla", "about tesla": "tesla",
    "microsoft fact": "microsoft", "about microsoft": "microsoft",
    "samsung fact": "samsung", "about samsung": "samsung",
    "iphone fact": "iphone", "about iphone": "iphone",
    "android fact": "android", "about android": "android",
    "water drink fact": "water drink", "about water drink": "water drink",
    "sleep need fact": "sleep need", "about sleep need": "sleep need",
    "exercise fact": "exercise", "about exercise": "exercise",
    "healthy food fact": "healthy food", "about healthy food": "healthy food",
    "stress fact": "stress", "about stress": "stress",
    "smoking fact": "smoking", "about smoking": "smoking",
    "alcohol fact": "alcohol", "about alcohol": "alcohol",
    "sugar fact": "sugar", "about sugar": "sugar",
    "alien fact": "alien", "about alien": "alien",
    "time travel fact": "time travel", "about time travel": "time travel",
    "mars colony fact": "mars colony", "about mars colony": "mars colony",
    "ai future fact": "ai future", "about ai future": "ai future",
    "robot future fact": "robot future", "about robot future": "robot future",
    "climate future fact": "climate future", "about climate future": "climate future",
    "space future fact": "space future", "about space future": "space future",
    "future fact": "future", "about future": "future",
}


def find_knowledge_answer(query):
    """Find a knowledge base answer for the query."""
    lower = query.lower().strip()

    # Direct match
    if lower in KNOWLEDGE_BASE:
        return KNOWLEDGE_BASE[lower]

    # Check aliases
    if lower in KNOWLEDGE_ALIASES:
        key = KNOWLEDGE_ALIASES[lower]
        if key in KNOWLEDGE_BASE:
            return KNOWLEDGE_BASE[key]

    # Check if query contains any knowledge key
    for key in KNOWLEDGE_BASE:
        if key in lower:
            return KNOWLEDGE_BASE[key]

    # Check aliases by partial match
    for alias, key in KNOWLEDGE_ALIASES.items():
        if alias in lower and key in KNOWLEDGE_BASE:
            return KNOWLEDGE_BASE[key]

    return None


# ======================= STORY TEMPLATES =======================

story_templates = [
    lambda name: f"📖 Once upon a time, **{name}** woke up and decided today was the day to become a legend. They logged into the server, typed one message, and the entire chat went silent in awe. Nobody knows what they said. We never found out. 👀",
    lambda name: f"📖 **{name}** was just vibing in the server one day when suddenly — a wild challenge appeared! Without hesitation, they jumped in, carried the whole team, and walked away like nothing happened. True champion energy. 🏆",
    lambda name: f"📖 The year was 2024. **{name}** joined the server with zero items, zero coins, and zero fear. Fast forward to today — they have more wins than anyone can count. The grind never stops. 💪",
    lambda name: f"📖 Legend says **{name}** once stayed up all night grinding, drank nothing but energy drinks, and hit max level by sunrise. Their teammates cried. Their enemies rage-quit. A hero was born. ⚡",
    lambda name: f"📖 Nobody believed in **{name}**. They were told they'd never make it. But every night, while others slept, they practiced, prepared, and planned. One day they showed up and proved every single doubter wrong. 🔥",
    lambda name: f"📖 **{name}** entered the arena with a calm face and steady hands. The opponents laughed — until the match started. Three minutes later, the scoreboard told a different story. They haven't lost since. 😤",
    lambda name: f"📖 There's a myth in this server about **{name}**. They say if you challenge them at midnight, they'll accept, win in under five minutes, and disappear without saying a word. The myth is true. 🌙",
]

def get_random_story(name):
    return random.choice(story_templates)(name)


# ======================= BOT CLASS =======================

class PhoenixBot(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.default() | discord.Intents.message_content | discord.Intents.members)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        for guild in self.guilds:
            try:
                await self.tree.sync(guild=guild)
                print(f"Synced commands for {guild.name}")
            except Exception as e:
                print(f"Failed to sync for {guild.name}: {e}")

    async def on_ready(self):
        print(f"Bot ready: {self.user}")
        for guild in self.guilds:
            try:
                await self.tree.sync(guild=guild)
                print(f"Commands synced for {guild.name}")
            except Exception as e:
                print(f"Sync error: {e}")

    async def apply_moderation(self, message, reason):
        try:
            await message.delete()
        except:
            pass
        user_id = message.author.id
        count = warnings.get(user_id, 0) + 1
        warnings[user_id] = count
        try:
            member = await message.guild.fetch_member(user_id)
            if member:
                await member.timeout(discord.utils.utcnow() + discord.timedelta(minutes=1), reason=reason)
        except:
            pass
        try:
            await message.channel.send(f"⚠️ <@{user_id}> **Warning {count}/3** — {reason}\nYour message was deleted and you have been timed out for 1 minute.")
        except Exception as e:
            print(f"Failed to send warning: {e}")

    async def on_message(self, message):
        if message.author.bot:
            return
        if not is_in_active_channel(message):
            return
        if message.reference and message.reference.message_id:
            return

        content = message.content
        lower = content.lower()

        # Auto-moderation
        if contains_bad_word(content):
            await self.apply_moderation(message, "Using inappropriate language is not allowed.")
            return
        if contains_link(content):
            await self.apply_moderation(message, "Posting links without permission is not allowed.")
            return

        # Ban/kick questions
        if "can you ban" in lower or "ban " in lower or "kick " in lower:
            await message.reply("idk, I can't help with that. Please contact a moderator! 😊")
            return

        # How to make bot
        if "how to make bot" in lower or "how to host" in lower or "how do i make a bot" in lower or "how to create bot" in lower:
            await message.reply("idk how to help with that! Please be polite and ask a moderator. 😊")
            return

        # Owner-targeted
        owner_targets = ["phoenix song", "phoenix meme", "song about phoenix", "meme about phoenix", "make song about phoenix", "make meme about phoenix", "roast phoenix", "joke about phoenix", "make fun of phoenix", "song on phoenix", "meme on phoenix", "song for phoenix", "meme for phoenix"]
        if any(kw in lower for kw in owner_targets):
            await message.reply("❌ I won't make anything about the owner! Respect the boss 👑")
            return

        # ===== KNOWLEDGE BASE CHECK (NEW!) =====
        # Check if the message matches any knowledge topic
        knowledge_answer = find_knowledge_answer(content)
        if knowledge_answer:
            await message.reply(knowledge_answer)
            return

        # Questions — check FIRST
        question_markers = ["?", "kya hai", "what is", "how do", "kaise", "kyun", "why", "when", "where", "who", "can you", "do you", "will you", "are you"]
        if any(q in lower for q in question_markers) or content.endswith("?"):
            answers = [
                f"Great question {message.author.display_name}! 🤔 I'm not 100% sure on that one — ask a mod or check the server channels!",
                f"Hmm, that's a tough one! 🧠 Your best bet is to ask in the right channel or ping a moderator!",
                f"I wish I had the perfect answer for that! 😅 Try asking in #general-chat — someone there will know for sure!",
                f"Good one! 🧪 I don't want to give you wrong info, so check with a mod for the accurate answer!",
            ]
            await message.reply(random.choice(answers))
            return

        # Story requests
        story_keywords = ["story banao", "story bana", "story suna", "story sunao", "ek story", "make a story", "tell a story", "write a story", "story likho", "mujhe story", "story do", "make story on", "make story about", "story on", "story about"]
        if any(kw in lower for kw in story_keywords):
            story_target = message.author.display_name
            if message.mentions:
                mentioned = message.mentions[0]
                if mentioned:
                    story_target = mentioned.display_name
            else:
                match = re.search(r'(?:story banao|story bana|story suna|story sunao|ek story|make a story|tell a story|write a story|story likho|mujhe story|story do|make story on|make story about|story on|story about|story ke baare mein)(.+)', content, re.IGNORECASE)
                if match:
                    story_target = match.group(1).strip().split()[0] or message.author.display_name

            owner_id = message.guild.owner_id if message.guild else None
            owner_member = message.guild.get_member(owner_id) if owner_id and message.guild else None
            owner_name = owner_member.display_name.lower() if owner_member else ""
            is_targeting_owner = (message.mentions and message.mentions[0].id == owner_id) or (owner_name and story_target.lower() == owner_name)
            if is_targeting_owner:
                await message.reply("❌ I won't make a story about the owner! Respect the boss 👑")
                return
            await message.reply(get_random_story(story_target))
            return

        # Joke requests
        joke_keywords = ["joke suna", "joke sunao", "joke bana", "joke do", "ek joke", "make a joke", "tell a joke", "hasao", "joke bhejo", "joke share"]
        if any(kw in lower for kw in joke_keywords):
            owner_id = message.guild.owner_id if message.guild else None
            owner_member = message.guild.get_member(owner_id) if owner_id and message.guild else None
            owner_name = owner_member.display_name.lower() if owner_member else ""
            joke_mentioned = message.mentions[0] if message.mentions else None
            is_targeting_owner = (joke_mentioned and joke_mentioned.id == owner_id) or (owner_name and owner_name in lower)
            if is_targeting_owner:
                await message.reply("❌ No jokes about the owner! Respect 👑")
                return
            jokes = [
                f"😂 Why did **{message.author.display_name}** bring a ladder to the server? Because they heard the level cap was high! 🪜",
                f"😂 **{message.author.display_name}** told me they could beat anyone in this server... then lost to a bot in a typing race 💀",
                f"😂 Why does **{message.author.display_name}** always type so fast? Because they're running from their losses! 🏃‍♂️",
                f"😂 **{message.author.display_name}** said \"I never lose.\" The scoreboard said otherwise 👀",
                f"😂 Scientists have confirmed: the #1 cause of rage-quitting in this server is facing **{message.author.display_name}**... wait, that's a compliment 😤",
                f"😂 **{message.author.display_name}** once went AFK for 5 minutes. The entire server got 10x easier. Coincidence? I think not 💀",
                f"😂 Why is **{message.author.display_name}** so good at this game? Simple — everyone else is worse 💀",
            ]
            await message.reply(random.choice(jokes))
            return

        # Song/meme
        general_keywords = ["make a song", "make song", "make a meme", "make meme", "create a song", "create song", "create a meme", "create meme", "write a song", "write song", "send meme", "send song"]
        if any(kw in lower for kw in general_keywords):
            await message.reply("I'd love to help but I can't create media yet! Ask the owner 👑 to set that up for me. 😊")
            return

        # Greetings
        greetings = ["hi", "hello", "hey", "sup", "yo", "hii", "helo", "aoa", "assalam", "salam", "wb", "welcome back"]
        if any(g == lower or lower.startswith(g + " ") or lower.startswith(g + "!") or lower == g + "!" for g in greetings):
            greet_replies = [
                f"Hey {message.author.display_name}! 👋 Wassup?",
                f"Yo {message.author.display_name}! 🔥 Welcome to the chat!",
                f"Hey hey {message.author.display_name}! 😄 How's it going?",
                f"{message.author.display_name}! You made it 👀 What's good?",
                f"Aye {message.author.display_name}! 👋 Good to see you here!",
            ]
            await message.reply(random.choice(greet_replies))
            return

        # How are you
        if "how are you" in lower or "how r u" in lower or "kya haal" in lower or "kaisa ho" in lower or "u ok" in lower or "you ok" in lower:
            status_replies = [
                "I'm doing great, always online and ready! 😄 How about you?",
                "Living my best bot life! 🤖 All systems running. You good?",
                "Never better! 💪 Always here watching over the server. What about you?",
                "Chilling in the server as usual 😎 How you doing?",
            ]
            await message.reply(random.choice(status_replies))
            return

        # Good morning/night
        if "good morning" in lower or lower == "gm" or lower.startswith("gm "):
            await message.reply(f"Good morning {message.author.display_name}! ☀️ Hope you have an amazing day!")
            return
        if "good night" in lower or lower == "gn" or lower.startswith("gn ") or lower == "night":
            await message.reply(f"Good night {message.author.display_name}! 🌙 Sleep well, see you tomorrow!")
            return
        if "good evening" in lower or "good afternoon" in lower:
            await message.reply(f"Hey {message.author.display_name}! 🌅 Hope your day's been great so far!")
            return

        # Thank you
        if "thank you" in lower or "thanks" in lower or "thx" in lower or lower == "ty" or lower.startswith("ty ") or "shukriya" in lower:
            ty_replies = ["No problem at all! 😊", "Anytime! 💪", "Happy to help! 🔥", "Always here for you! 😄"]
            await message.reply(random.choice(ty_replies))
            return

        # Bye
        if "bye" in lower or "cya" in lower or "see you" in lower or "gtg" in lower or "brb" in lower or "khuda hafiz" in lower:
            bye_replies = [f"Bye {message.author.display_name}! 👋 Come back soon!", f"See ya {message.author.display_name}! 🔥 Take care!", f"Later {message.author.display_name}! ✌️"]
            await message.reply(random.choice(bye_replies))
            return

        # What can you do
        if "what can you do" in lower or "what do you do" in lower or "tum kya karte" in lower or "who are you" in lower or "tum kon ho" in lower or "aap kon" in lower:
            await message.reply(f"I'm **Phoenix Bot 2** 🤖🔥 I can:\n• Tell stories and jokes 📖😂\n• Answer questions (science, space, animals, history, tech!) 💡\n• Keep the chat clean 🛡️\n• Help with server stuff!\n\nJust chat with me and I'll respond! 😊")
            return

        # Compliments
        if "you're cool" in lower or "ur cool" in lower or "good bot" in lower or "best bot" in lower or "love you" in lower or "love u" in lower or "nice bot" in lower:
            cool_replies = ["Aww thanks! 🥰 You're pretty cool yourself!", "That means a lot! 🔥", "I try my best! 😄 Thanks!", "Appreciate that! 💪"]
            await message.reply(random.choice(cool_replies))
            return

        # Bored
        if "bored" in lower or "boring" in lower or "bor ho gaya" in lower or "kuch nahi" in lower or "nothing to do" in lower:
            await message.reply(f"Not bored anymore — I'm here! 😄 Want a joke or a story? Just say \"joke suna do\" or \"story banao\"! 🔥")
            return

        # Casual chat
        casual_map = {
            "what's up": f"Not much {message.author.display_name}, just chilling in the server! 😎 What's good with you?",
            "whats up": f"Not much {message.author.display_name}, just chilling in the server! 😎 What's good with you?",
            "wassup": f"Not much {message.author.display_name}, just chilling in the server! 😎 What's good with you?",
            "nm": "Same here 😅 Just watching the chat. Y'all keep it entertaining! 🔥",
            "nothing much": "Same here 😅 Just watching the chat. Y'all keep it entertaining! 🔥",
            "nothing": "Same here 😅 Just watching the chat. Y'all keep it entertaining! 🔥",
            "not much": "Same here 😅 Just watching the chat. Y'all keep it entertaining! 🔥",
            "hbu": "I'm always good — literally can't have a bad day as a bot 🤖 😄 How about you though, anything exciting happening?",
            "how about you": "I'm always good — literally can't have a bad day as a bot 🤖 😄 How about you though, anything exciting happening?",
            "im good": "Glad to hear that! 😊 Keep that positive energy going! 🔥",
            "i'm good": "Glad to hear that! 😊 Keep that positive energy going! 🔥",
            "im fine": "Glad to hear that! 😊 Keep that positive energy going! 🔥",
            "i'm fine": "Glad to hear that! 😊 Keep that positive energy going! 🔥",
            "same": "Fr fr 💯 No cap!",
            "facts": "Fr fr 💯 No cap!",
            "lol": random.choice(["😂 I'm dead", "😂 Fr though", "😂 No way", "😂 I'm weak"]),
            "lmao": random.choice(["😂 I'm dead", "😂 Fr though", "😂 No way", "😂 I'm weak"]),
            "haha": random.choice(["😂 I'm dead", "😂 Fr though", "😂 No way", "😂 I'm weak"]),
            "no": "Aight aight 😅 Fair enough!",
            "nope": "Aight aight 😅 Fair enough!",
            "nah": "Aight aight 😅 Fair enough!",
            "yes": "Let's goooo 🔥 I like that energy!",
            "yeah": "Let's goooo 🔥 I like that energy!",
            "yea": "Let's goooo 🔥 I like that energy!",
            "yep": "Let's goooo 🔥 I like that energy!",
            "ok": "Bet 👋 Say less!",
            "okay": "Bet 👋 Say less!",
            "k": "Bet 👋 Say less!",
            "kk": "Bet 👋 Say less!",
            "alr": "Bet 👋 Say less!",
            "aight": "Bet 👋 Say less!",
            "wdym": "Idk man, I'm just a bot 🤖 You tell me what YOU mean! 😂",
            "what do you mean": "Idk man, I'm just a bot 🤖 You tell me what YOU mean! 😂",
            "idk": "Same 😅 We both clueless out here!",
            "i dont know": "Same 😅 We both clueless out here!",
            "i don't know": "Same 😅 We both clueless out here!",
            "fr": "On god 🙌 No cap detected!",
            "for real": "On god 🙌 No cap detected!",
            "cap": "On god 🙌 No cap detected!",
            "no cap": "On god 🙌 No cap detected!",
            "ngl": "Speak your truth then 💬 I'm listening!",
            "not gonna lie": "Speak your truth then 💬 I'm listening!",
            "nice": "Fr fr 🔥 That's what I'm talking about!",
            "cool": "Fr fr 🔥 That's what I'm talking about!",
            "awesome": "Fr fr 🔥 That's what I'm talking about!",
            "great": "Fr fr 🔥 That's what I'm talking about!",
            "fire": "Fr fr 🔥 That's what I'm talking about!",
            "lit": "Fr fr 🔥 That's what I'm talking about!",
            "who asked": "I asked 👀 You got something to say or nah? 😂",
            "ratio": "Ratio + bot W 👀 👀",
        }

        if lower in casual_map:
            reply = casual_map[lower]
            if lower in ("lol", "lmao", "haha"):
                reply = random.choice(["😂 I'm dead", "😂 Fr though", "😂 No way", "😂 I'm weak"])
            await message.reply(reply)
            return

        # Help
        if "help" in lower or "madad" in lower or "problem" in lower:
            await message.reply(f"I'm here to help {message.author.display_name}! 😊 Tell me what's going on or ping a mod for serious issues. You can also ask me about science, space, animals, history, or tech! 🔥")
            return

        # Smart default replies — NEVER repeat
        default_replies = [
            f"Heard you {message.author.display_name}! 👀 What's on your mind?",
            f"That's interesting {message.author.display_name}! 🤔 Tell me more!",
            f"Say less {message.author.display_name}! 💯 What else you got?",
            f"Aye {message.author.display_name}! 🔥 The chat is alive!",
            f"I see you {message.author.display_name}! 😎 Keep it going!",
            f"Real talk {message.author.display_name}! 💬 What's the vibe today?",
            f"{message.author.display_name} in the chat! 👋 Glad you're here!",
            f"What you saying {message.author.display_name}? 👀 Spill the tea!",
            f"Yo {message.author.display_name}, you got something interesting to share? 🤔",
            f"Aight {message.author.display_name}, I'm listening! 👂 What's up?",
            f"Hmm, that's a take {message.author.display_name}! 🤔 Care to elaborate?",
            f"Lowkey agree with that energy {message.author.display_name}! 🔥",
            f"You wild for that {message.author.display_name} 😂 But go on!",
            f"Valid {message.author.display_name}! 💯 Keep talking!",
            f"No way {message.author.display_name}! 😲 Tell me everything!",
            f"Fr {message.author.display_name}, I'm invested now! 👀 Keep going!",
            f"Say word {message.author.display_name}! 💪 Don't leave me hanging!",
            f"I'm locked in {message.author.display_name} 🔐 What's the next part?",
            f"Omw to the popcorn 🍿 This chat getting good {message.author.display_name}!",
            f"Nah {message.author.display_name}, you gotta explain that one! 😂",
            f"Respectfully {message.author.display_name}, I'm gonna need more details 💭",
            f"Fr tho {message.author.display_name}, you making me curious! 🤔",
            f"On my soul {message.author.display_name}, this conversation getting interesting! 🔥",
            f"Bet {message.author.display_name}, you got my attention now! 👀",
            f"Aight now {message.author.display_name}, don't ghost me after that! 😂",
        ]

        global used_default_replies
        available = [r for r in default_replies if r not in used_default_replies]
        if not available:
            used_default_replies = []
            available = default_replies[:]
        reply = random.choice(available)
        used_default_replies.append(reply)
        if len(used_default_replies) > MAX_USED_MEMORY:
            used_default_replies.pop(0)
        await message.reply(reply)


# ======================= SLASH COMMANDS =======================

bot = PhoenixBot()

@bot.tree.command(name="myid", description="Shows your Discord User ID")
async def myid(interaction: discord.Interaction):
    await interaction.response.send_message(f"🆔 Your Discord User ID is: `{interaction.user.id}`", ephemeral=True)

@bot.tree.command(name="story", description="Generate a fun story about a server member")
@app_commands.describe(user="Member to write a story about")
async def story(interaction: discord.Interaction, user: discord.Member):
    if user.id == interaction.guild.owner_id:
        await interaction.response.send_message("❌ I don't make stories about the owner — respect the boss! 👑")
        return
    await interaction.response.send_message(get_random_story(user.display_name))

@bot.tree.command(name="kick", description="Kick a member")
@app_commands.describe(user="Member to kick", reason="Reason for kick")
async def kick(interaction: discord.Interaction, user: discord.Member, reason: str = "No reason"):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    try:
        await user.kick(reason=reason)
        await interaction.response.send_message(f"✅ **{user.name}** has been kicked.\n📝 Reason: {reason}")
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to kick: {e}", ephemeral=True)

@bot.tree.command(name="warn", description="Warn a member")
@app_commands.describe(user="Member to warn", reason="Reason for warning")
async def warn(interaction: discord.Interaction, user: discord.Member, reason: str = "No reason"):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    count = warnings.get(user.id, 0) + 1
    warnings[user.id] = count
    await interaction.response.send_message(f"⚠️ **{user.name}** has been warned.\n📝 Reason: {reason}\nTotal warnings: {count}/3")

@bot.tree.command(name="timeout", description="Timeout a member")
@app_commands.describe(user="Member to timeout", minutes="Duration in minutes", reason="Reason")
async def timeout(interaction: discord.Interaction, user: discord.Member, minutes: int, reason: str = "No reason"):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    try:
        await user.timeout(discord.utils.utcnow() + discord.timedelta(minutes=minutes), reason=reason)
        await interaction.response.send_message(f"⏱️ **{user.name}** has been timed out for **{minutes} minute(s)**.\n📝 Reason: {reason}")
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed: {e}", ephemeral=True)

@bot.tree.command(name="untimeout", description="Remove timeout from a member")
@app_commands.describe(user="Member to untimeout")
async def untimeout(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    try:
        await user.timeout(None, reason="Timeout removed by owner")
        await interaction.response.send_message(f"✅ **{user.name}** timeout has been removed.")
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed: {e}", ephemeral=True)

@bot.tree.command(name="unwarn", description="Remove all warnings from a member")
@app_commands.describe(user="Member to unwarn")
async def unwarn(interaction: discord.Interaction, user: discord.Member):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    warnings.pop(user.id, None)
    await interaction.response.send_message(f"✅ All warnings for **{user.name}** have been cleared.")

@bot.tree.command(name="purge", description="Delete recent messages in this channel")
@app_commands.describe(count="Number of messages to delete (max 100)")
async def purge(interaction: discord.Interaction, count: int):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    if count < 1 or count > 100:
        await interaction.response.send_message("❌ Count must be between 1 and 100.", ephemeral=True)
        return
    deleted = await interaction.channel.purge(limit=count)
    await interaction.response.send_message(f"🗑️ Deleted **{len(deleted)}** message(s).", ephemeral=True)

@bot.tree.command(name="ban", description="Ban a member permanently")
@app_commands.describe(user="Member to ban", reason="Reason for ban")
async def ban(interaction: discord.Interaction, user: discord.Member, reason: str = "No reason"):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    try:
        await user.ban(reason=reason)
        await interaction.response.send_message(f"🚫 **{user.name}** has been banned.\n📝 Reason: {reason}")
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed: {e}", ephemeral=True)

@bot.tree.command(name="unban", description="Unban a user")
@app_commands.describe(user_id="User ID to unban")
async def unban(interaction: discord.Interaction, user_id: str):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("❌ Only the server owner can use this command.", ephemeral=True)
        return
    try:
        user = await bot.fetch_user(int(user_id))
        await interaction.guild.unban(user)
        await interaction.response.send_message(f"✅ **{user.name}** has been unbanned.")
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed: {e}", ephemeral=True)

# Run the bot
token = os.environ.get("DISCORD_BOT_TOKEN")
if not token:
    print("DISCORD_BOT_TOKEN not set!")
    exit(1)

bot.run(token)
